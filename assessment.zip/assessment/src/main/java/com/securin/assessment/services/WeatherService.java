package com.securin.assessment.services;

import com.securin.assessment.dto.WeatherFilterDto;
import com.securin.assessment.entity.WeatherData;
import com.securin.assessment.repository.WeatherRepository;
import jakarta.persistence.criteria.Predicate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

@Service
public class WeatherService {

    @Autowired
    private WeatherRepository repository;

    public void uploadCSV(MultipartFile file) throws Exception {

        BufferedReader reader =
                new BufferedReader(new InputStreamReader(file.getInputStream()));

        List<WeatherData> list = new ArrayList<>();
        String line;
        reader.readLine();

        while ((line = reader.readLine()) != null) {

            String[] d = line.split(",");

            WeatherData w = new WeatherData();

            w.setDatetime(d[0]);
            w.setConds(d[1]);
            w.setDewptm(parseInt(d[2]));
            w.setFog(parseInt(d[3]));
            w.setHail(parseInt(d[4]));
            w.setHeatindexm(parseInt(d[5]));
            w.setHum(parseInt(d[6]));
            w.setPrecipm(parseDouble(d[7]));
            w.setPressurem(parseInt(d[8]));
            w.setRain(parseInt(d[9]));
            w.setSnow(parseInt(d[10]));
            w.setTempm(parseInt(d[11]));
            w.setThunder(parseInt(d[12]));
            w.setTornado(parseInt(d[13]));
            w.setVism(parseDouble(d[14]));
            w.setWdird(parseInt(d[15]));
            w.setWdire(d[16]);
            w.setWgustm(parseDouble(d[17]));
            w.setWindchillm(parseDouble(d[18]));
            w.setWspdm(parseDouble(d[19]));

            list.add(w);
        }

        repository.saveAll(list);
    }

    private Integer parseInt(String v) {
        return (v == null || v.isEmpty() || v.equals("-9999"))
                ? null : Integer.parseInt(v);
    }

    private Double parseDouble(String v) {
        return (v == null || v.isEmpty() || v.equals("-9999"))
                ? null : Double.parseDouble(v);
    }

    public List<WeatherData> filter(WeatherFilterDto dto) {

        Specification<WeatherData> spec = (root, query, cb) -> {

            List<Predicate> p = new ArrayList<>();

            if (dto.getStartDate() != null)
                p.add(cb.greaterThanOrEqualTo(root.get("datetime"), dto.getStartDate()));

            if (dto.getEndDate() != null)
                p.add(cb.lessThanOrEqualTo(root.get("datetime"), dto.getEndDate()));

            if (dto.getMintemp() != null)
                p.add(cb.greaterThanOrEqualTo(root.get("tempm"), dto.getMintemp()));

            if (dto.getMaxtemp() != null)
                p.add(cb.lessThanOrEqualTo(root.get("tempm"), dto.getMaxtemp()));

            if (dto.getConds() != null)
                p.add(cb.equal(root.get("conds"), dto.getConds()));

            if (dto.getRain() != null)
                p.add(cb.equal(root.get("rain"), dto.getRain()));

            return cb.and(p.toArray(new Predicate[0]));
        };

        Sort sort = Sort.unsorted();

        if (dto.getSortby() != null) {
            sort = "desc".equalsIgnoreCase(dto.getDirection())
                    ? Sort.by(dto.getSortby()).descending()
                    : Sort.by(dto.getSortby()).ascending();
        }

        return repository.findAll(spec, sort);
    }
}