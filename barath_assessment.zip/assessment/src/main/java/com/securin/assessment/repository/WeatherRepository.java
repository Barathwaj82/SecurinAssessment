package com.securin.assessment.repository;

import com.securin.assessment.entity.WeatherData;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

public interface WeatherRepository extends
        JpaRepository<WeatherData, Long>,
        JpaSpecificationExecutor<WeatherData> {
}