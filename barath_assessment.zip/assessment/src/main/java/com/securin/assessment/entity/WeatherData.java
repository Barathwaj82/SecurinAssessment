package com.securin.assessment.entity;

import jakarta.persistence.*;

@Entity
@Table(name = "weather_data")
public class WeatherData {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String datetime;
    private String conds;
    private Integer dewptm;
    private Integer fog;
    private Integer hail;
    private Integer heatindexm;
    private Integer hum;
    private Double precipm;
    private Integer pressurem;
    private Integer rain;
    private Integer snow;
    private Integer tempm;
    private Integer thunder;
    private Integer tornado;
    private Double vism;
    private Integer wdird;
    private String wdire;
    private Double wgustm;
    private Double windchillm;
    private Double wspdm;

    // Getters and Setters

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getDatetime() { return datetime; }
    public void setDatetime(String datetime) { this.datetime = datetime; }

    public String getConds() { return conds; }
    public void setConds(String conds) { this.conds = conds; }

    public Integer getDewptm() { return dewptm; }
    public void setDewptm(Integer dewptm) { this.dewptm = dewptm; }

    public Integer getFog() { return fog; }
    public void setFog(Integer fog) { this.fog = fog; }

    public Integer getHail() { return hail; }
    public void setHail(Integer hail) { this.hail = hail; }

    public Integer getHeatindexm() { return heatindexm; }
    public void setHeatindexm(Integer heatindexm) { this.heatindexm = heatindexm; }

    public Integer getHum() { return hum; }
    public void setHum(Integer hum) { this.hum = hum; }

    public Double getPrecipm() { return precipm; }
    public void setPrecipm(Double precipm) { this.precipm = precipm; }

    public Integer getPressurem() { return pressurem; }
    public void setPressurem(Integer pressurem) { this.pressurem = pressurem; }

    public Integer getRain() { return rain; }
    public void setRain(Integer rain) { this.rain = rain; }

    public Integer getSnow() { return snow; }
    public void setSnow(Integer snow) { this.snow = snow; }

    public Integer getTempm() { return tempm; }
    public void setTempm(Integer tempm) { this.tempm = tempm; }

    public Integer getThunder() { return thunder; }
    public void setThunder(Integer thunder) { this.thunder = thunder; }

    public Integer getTornado() { return tornado; }
    public void setTornado(Integer tornado) { this.tornado = tornado; }

    public Double getVism() { return vism; }
    public void setVism(Double vism) { this.vism = vism; }

    public Integer getWdird() { return wdird; }
    public void setWdird(Integer wdird) { this.wdird = wdird; }

    public String getWdire() { return wdire; }
    public void setWdire(String wdire) { this.wdire = wdire; }

    public Double getWgustm() { return wgustm; }
    public void setWgustm(Double wgustm) { this.wgustm = wgustm; }

    public Double getWindchillm() { return windchillm; }
    public void setWindchillm(Double windchillm) { this.windchillm = windchillm; }

    public Double getWspdm() { return wspdm; }
    public void setWspdm(Double wspdm) { this.wspdm = wspdm; }
}