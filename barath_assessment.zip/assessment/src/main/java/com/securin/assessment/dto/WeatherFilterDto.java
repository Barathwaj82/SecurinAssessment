package com.securin.assessment.dto;

public class WeatherFilterDto {

    private String startDate;
    private String endDate;
    private Integer mintemp;
    private Integer maxtemp;
    private String conds;
    private Integer rain;
    private String sortby;
    private String direction;

    public String getStartDate() { return startDate; }
    public void setStartDate(String startDate) { this.startDate = startDate; }

    public String getEndDate() { return endDate; }
    public void setEndDate(String endDate) { this.endDate = endDate; }

    public Integer getMintemp() { return mintemp; }
    public void setMintemp(Integer mintemp) { this.mintemp = mintemp; }

    public Integer getMaxtemp() { return maxtemp; }
    public void setMaxtemp(Integer maxtemp) { this.maxtemp = maxtemp; }

    public String getConds() { return conds; }
    public void setConds(String conds) { this.conds = conds; }

    public Integer getRain() { return rain; }
    public void setRain(Integer rain) { this.rain = rain; }

    public String getSortby() { return sortby; }
    public void setSortby(String sortby) { this.sortby = sortby; }

    public String getDirection() { return direction; }
    public void setDirection(String direction) { this.direction = direction; }
}