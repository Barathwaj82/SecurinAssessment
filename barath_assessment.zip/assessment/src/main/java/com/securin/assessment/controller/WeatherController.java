package com.securin.assessment.controller;

import com.securin.assessment.dto.WeatherFilterDto;
import com.securin.assessment.entity.WeatherData;
import com.securin.assessment.services.WeatherService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;

@RestController
@RequestMapping("/api/weather")
public class WeatherController {

    @Autowired
    private WeatherService service;

    @PostMapping("/upload")
    public String upload(@RequestParam("file") MultipartFile file)
            throws Exception {
        service.uploadCSV(file);
        return "CSV Uploaded Successfully!";
    }

    @PostMapping("/filter")
    public List<WeatherData> filter(@RequestBody WeatherFilterDto dto) {
        return service.filter(dto);
    }

    @PostMapping("/filter-sort")
    public List<WeatherData> filterSort(@RequestBody WeatherFilterDto dto) {
        return service.filter(dto);
    }
}