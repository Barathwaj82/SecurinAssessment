

{
	  "startDate": "19961101",
	  "endDate": "19961130",
	  "minTemp": 20,
	  "maxTemp": 35,
	  "conds": "Smoke",
	  "rain": 0,
	  "sortBy": "tempm",
	  "direction": "desc"
	}

}